#!/bin/sh
# Add the following line in /etc/crontab
# * * * * * root /home/pi/restart_snapclient.sh
#
status=$(sudo systemctl status snapclient | grep -E "Connection refused")
if [ ! -z "$status" ]; then
        sudo systemctl restart snapclient
fi
