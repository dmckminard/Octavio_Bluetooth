#!/usr/bin/env python3
import subprocess
import time
import os
import sys
import ipaddress
#from urllib.request import urlopen
import urllib.request
from urllib.error import HTTPError, URLError
from socket import timeout
cmd = ["sudo", "service","snapclient","status"]


print ("CHANGEMENT DE SERVEUR")

try :
    p = subprocess.Popen(["ps", "-A"], stdout=subprocess.PIPE)
    out, err = p.communicate()
    if ('snapserver' in str(out)):
        print('Je suis serveur')
        sys.exit()
    else:
        print('Je suis client, je deviens serveur')
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
        lastLine = (proc.stdout.readlines()[-1]).decode()
        global ipServ
        ipServ = lastLine.split(" ")[-1]
        print("ip server : " + ipServ)
        ip = str(ipaddress.ip_address(ipServ.rstrip()))
        print('Kill client')
        subprocess.call(["sudo", "pkill", "-9", "-f", "client.py"])
        url = ("http://"+ip+":8000/cgi-bin/setclient.py")
        print('Open url')
        try:
                response = urllib.request.urlopen(url, timeout=3).read().decode('utf-8')
        except :
                print('timeout')
                print('lancement server.py')
                subprocess.Popen(["python3", "/home/config/bin/server.py"])
                print('SCRIPT OK')
                sys.exit()
except KeyboardInterrupt:
    sys.exit()
