#!/usr/bin/env python
import subprocess

subprocess.Popen(["sudo", "-u", "config", "python3", "/home/config/bin/show_leds.py", "|logger -t octavio"], cwd="/home/config/bin")
