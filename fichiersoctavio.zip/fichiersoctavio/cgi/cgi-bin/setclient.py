#!/usr/bin/env python3
import subprocess
import time
import os
import sys

print ("CHANGEMENT DE SERVEUR")

try :
    p = subprocess.Popen(["ps", "-A"], stdout=subprocess.PIPE)
    out, err = p.communicate()
    if ('snapserver' in str(out)):
        print('Je suis serveur, je deviens client')
        subprocess.call(["pkill", "-9", "-f", "server.py"])
        subprocess.call(["sudo", "service", "snapserver", "stop"])
        subprocess.call(["python3", "/home/config/bin/wait_server.py"])
        print('LANCEMENT CGI')
        subprocess.Popen(["python3", "/home/config/cgi/cgiserver.py"])
        print("CGI STARTED")
        sys.exit()
    else :
        print('Je ne suis pas le serveur')
        print('LANCEMENT CGI, JE NE SUIS PAS SERVER')
        sys.exit()
except KeyboardInterrupt:
    sys.exit()
