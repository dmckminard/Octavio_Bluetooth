#!/usr/bin/env python3

from http.server import CGIHTTPRequestHandler, HTTPServer

print('LANCEMENT CGI')
handler = CGIHTTPRequestHandler
handler.cgi_directories = ["/cgi-bin"]  # this is the default
server = HTTPServer(('0.0.0.0', 8000), handler)
print('CGI STARTED')
server.serve_forever()
