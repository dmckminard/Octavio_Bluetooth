#!/bin/sh

# Add the following line in /etc/crontab
# * * * * * root /home/pi/restart_spotify.sh
#

status=$(sudo systemctl status raspotify | grep -E "(WARN|ERROR|101)")

if [ ! -z "$status" ]; then
	sudo systemctl restart raspotify
fi
